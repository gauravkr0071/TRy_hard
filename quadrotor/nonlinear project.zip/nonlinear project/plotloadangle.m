%% clearing
clear all;
clc;
close all;
%% Initial position
xi=2;
yi=0;
zi=1;
psii=0;
%% lengths
M1=[0.1:0.5:2];
l1=[0.1:0.5:2];
lq=0.5;
%% Desired Position
xd=-1;
yd=2;
zd=3;
psid=0;
%% simulate
figure

for i=1:length(l1)
    Ml=M1(i);
    l=1;
    sim('quadrotor15a');
    xq=x.data;
    yq=y.data;
    zq=z.data;
    phiL=phil.data;
    thetaL=thetal.data;
    ag=subplot(2,1,1);
    plot(phil.time,phil.data.*180/pi);
    
    hold on;
    grid on;
    xlabel('Time(sec)');
    ylabel('\phi_l (degree)');
    title('Load angle');
    subplot(2,1,2);
    plot(thetal.time,thetal.data.*180/pi)
    hold on
    grid on
    xlabel('Time(sec)');
    ylabel('\theta_l (degree)');
end

legend(ag,['M_l=' num2str(l1(1)) 'kg'],['M_l=' num2str(l1(2)) 'kg'],['M_l=' num2str(l1(3)) 'Kg'],['M_l=' num2str(l1(4)) 'Kg']);