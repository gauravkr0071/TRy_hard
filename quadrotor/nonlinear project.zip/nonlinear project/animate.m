%% clearing
clear all;
clc;
close all;
%% Initial position
xi=2;
yi=0;
zi=1;
psii=0;
%% lengths
Ml=0.2;
l=1;
lq=0.5;
%% Desired Position
xd=-1;
yd=2;
zd=3;
psid=0;
%% simulate
sim('quadrotor15a');
%% data
xq=x.data;
yq=y.data;
zq=z.data;
phiL=phil.data;
thetaL=thetal.data;
phiq=phi.data;
thetaq=theta.data;
psiq=psi.data;
for i=1:length(xq)
xl(i)=xq(i)+l*cos(thetaL(i))*sin(phiL(i));
yl(i)=yq(i)+l*sin(thetaL(i));
zl(i)=zq(i)-l*cos(thetaL(i))*cos(phiL(i));
xl1(i)=lq/2;
yl1(i)=lq/2;
xl2(i)=lq/2;
yl2(i)=-lq/2;
xr1(i)=-lq/2;
yr1(i)=lq/2;
xr2(i)=-lq/2;
yr2(i)=-lq/2;
Rz=[cos(psiq(i)),-sin(psiq(i)),0;
    sin(psiq(i)),cos(psiq(i)),0;
    0,0,1];
Ry=[cos(thetaq(i)),0,sin(thetaq(i));
    0,1,0;
    -sin(thetaq(i)),0,cos(thetaq(i))];
Rx=[1,0,0;
    0,cos(phiq(i)),-sin(phiq(i));
    0,sin(phiq(i)),cos(phiq(i))];
R=Rz*Ry*Rx;
fl1=R*[xl1(i);yl1(i);0];
fl2=R*[xl2(i);yl2(i);0];
fr1=R*[xr1(i);yr1(i);0];
fr2=R*[xr2(i);yr2(i);0];
xql1(i)=xq(i)+fl1(1);
xql2(i)=xq(i)+fl2(1);
yql1(i)=yq(i)+fl1(2);
yql2(i)=yq(i)+fl2(2);
zql1(i)=zq(i)+fl1(3);
zql2(i)=zq(i)+fl2(3);
xqr1(i)=xq(i)+fr1(1);
xqr2(i)=xq(i)+fr2(1);
yqr1(i)=yq(i)+fr1(2);
yqr2(i)=yq(i)+fr2(2);
zqr1(i)=zq(i)+fr1(3);
zqr2(i)=zq(i)+fr2(3);
end
%% Animation
figure
pause(2);
plot3(xd,yd,zd,'*','color','r','LineWidth',2);
hold on
grid on
xlim([xd-2,3]);
ylim([-2,yd+1]);
zlim([-2.5,zd+1]);
for i=1:length(xq)
    
   a1=line([xq(i) xl(i)],[yq(i) yl(i)],[zq(i) zl(i)],'color','r');
   a2=line([xql1(i) xqr2(i)],[yql1(i) yqr2(i)],[zql1(i) zqr2(i)],'color','b'); 
   a3=line([xql2(i) xqr1(i)],[yql2(i) yqr1(i)],[zql2(i) zqr1(i)],'color','b');
   pause(0.2);
    if i<length(xq)
     delete(a1);
     delete(a3);
     delete(a2);
    end
    xlabel('x');
    ylabel('y');
    zlabel('z');
    
end
%% plot position
figure
subplot(3,1,1);

plot(x.time,x.data);
title('Position of Quadrotor');
grid on
xlabel('Time(sec)');
ylabel('x(m)');
subplot(3,1,2);
plot(x.time,y.data)
grid on
xlabel('Time(sec)');
ylabel('y(m)');
subplot(3,1,3);
plot(x.time,z.data)
grid on
xlabel('Time(sec)');
ylabel('z(m)');
%% plot  load angle
figure
subplot(2,1,1);
plot(phil.time,phil.data.*180/pi)
grid on
xlabel('Time(sec)');
ylabel('\phi_l (degree)');
title('Load angle');
subplot(2,1,2);
plot(thetal.time,thetal.data.*180/pi)
grid on
xlabel('Time(sec)');
ylabel('\theta_l (degree)');
%% plot orientation
figure
subplot(3,1,1);

plot(phi.time,phi.data);
title('Orientation of Quadrotor');
grid on
xlabel('Time(sec)');
ylabel('\phi (radian)');
subplot(3,1,2);
plot(theta.time,theta.data)
grid on
xlabel('Time(sec)');
ylabel('\theta (radian)');
subplot(3,1,3);
plot(psi.time,psi.data)
grid on
xlabel('Time(sec)');
ylabel('\psi (radian)');
%% plot linear velocity
figure
subplot(3,1,1);

plot(x_d.time,x_d.data);
title('linear velocity of Quadrotor');
grid on
xlabel('Time(sec)');
ylabel('xdot(m/sec)');
subplot(3,1,2);
plot(y_d.time,y_d.data)
grid on
xlabel('Time(sec)');
ylabel('ydot(m/sec)');
subplot(3,1,3);
plot(z_d.time,z_d.data)
grid on
xlabel('Time(sec)');
ylabel('zdot(m/sec)');
%% plot input force and torque
figure
subplot(4,1,1);

plot(Tb.time,Tb.data);
title('Inputs');
grid on
xlabel('Time(sec)');
ylabel('Force(N)');
subplot(4,1,2);
plot(T_phi.time,T_phi.data)
grid on
xlabel('Time(sec)');
ylabel('T_\phi(Nm)');
subplot(4,1,3);
plot(T_theta.time,T_theta.data)
grid on
xlabel('Time(sec)');
ylabel('T_\theta(Nm)');
subplot(4,1,4);
plot(T_psi.time,T_psi.data)
grid on
xlabel('Time(sec)');
ylabel('T_\psi(Nm)');

